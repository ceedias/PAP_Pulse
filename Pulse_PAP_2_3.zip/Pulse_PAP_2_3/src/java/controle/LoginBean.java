/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.SQLException;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import model.Pessoa;

/**
 *
 * @author cesardias
 */
@ManagedBean
@SessionScoped
public class LoginBean {

    /**
     * @return the pessoa
     */
    public Pessoa getPessoa() {
        return pessoa;
    }

    /**
     * @param pessoa the pessoa to set
     */
    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    /**
     * @return the dao
     */
    public LoginDAO getDao() {
        return dao;
    }

    /**
     * @param dao the dao to set
     */
    public void setDao(LoginDAO dao) {
        this.dao = dao;
    }
    private Pessoa pessoa = new Pessoa();
    private LoginDAO dao = new LoginDAO();
    
         public String verificaLogin(Pessoa pessoa) throws SQLException{
        pessoa.getClass();
                                                 if (getDao().verificaLogin(pessoa) == null){
       
                                                                FacesContext.getCurrentInstance().addMessage("growl",
                                                                       new FacesMessage("Não autorizado", "Nenhum registro foi encontrado com essas informações"));
                                                                             return null;

                                                                } else {
                                                                           return vaiParaIndex();
                                                                          }
         
         
         }   
         
         public String vaiParaIndex() {
		return "/view/index?faces-redirect=true";
	}
}
